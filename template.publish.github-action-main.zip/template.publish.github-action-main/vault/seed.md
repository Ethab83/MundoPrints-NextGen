---
id: ENDcCZFjAW9h66eDoFg7I
title: Seed
desc: ''
updated: 1654013219836
created: 1631921362276
nav_exclude_children: true
---


This is a page. Plant it and watch it grow.

[[seed.child]]